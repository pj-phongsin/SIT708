package com.example.personalizedlearningexperiencesapp.fragments;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.cardview.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.personalizedlearningexperiencesapp.MainActivity;
import com.example.personalizedlearningexperiencesapp.R;
import com.example.personalizedlearningexperiencesapp.model.QuizResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Home extends Fragment {

    private RequestQueue requestQueue;
    private ArrayList<QuizResponse.Question> quizList = new ArrayList<>();

    public Home() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        requestQueue = Volley.newRequestQueue(getContext());
        CardView generatedTaskCard = view.findViewById(R.id.generatedTaskCard);
        TextView generatedTaskTitle = view.findViewById(R.id.generatedTaskTitle);
        TextView generatedTaskDescription = view.findViewById(R.id.generatedTaskDescription);

        Bundle args = getArguments();
        if (args != null) {
            ArrayList<String> selectedTopics = args.getStringArrayList("selectedTopics");
            Log.d("HOME_FRAGMENT", "Selected topics: " + selectedTopics);

            if (selectedTopics != null && !selectedTopics.isEmpty()) {
                String topicString = String.join(",", selectedTopics);

                generatedTaskCard.setVisibility(View.VISIBLE); // show the card
                generatedTaskTitle.setText("Generated Task 1");
                generatedTaskDescription.setText(topicString);

                fetchQuizFromServer(topicString);

                generatedTaskCard.setOnClickListener(v -> {
                    if (quizList != null && !quizList.isEmpty()) {
                        Quiz quizFragment = new Quiz();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("quizData", quizList);
                        quizFragment.setArguments(bundle);

                        ((MainActivity) getActivity()).switchFragment(quizFragment);
                    } else {
                        Toast.makeText(getContext(), "Quiz not loaded yet. Please wait.", Toast.LENGTH_SHORT).show();
                    }
                });

            } else {
                Toast.makeText(getContext(), "No topics selected", Toast.LENGTH_SHORT).show();
            }
        }

        return view;
    }

    private void fetchQuizFromServer(String topic) {
        Log.d("FETCH_TOPIC", "Topic received for fetchQuiz: " + topic);

        String url = "http://10.0.2.2:5001/getQuiz?topic=" + topic;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray quizArray = response.getJSONArray("quiz");
                        quizList.clear();  // Clear before adding new

                        for (int i = 0; i < quizArray.length(); i++) {
                            JSONObject quizObject = quizArray.getJSONObject(i);
                            String questionText = quizObject.getString("question");
                            JSONArray optionsArray = quizObject.getJSONArray("options");
                            String correctAnswer = quizObject.getString("correct_answer");

                            ArrayList<String> optionsList = new ArrayList<>();
                            for (int j = 0; j < optionsArray.length(); j++) {
                                optionsList.add(optionsArray.getString(j));
                            }

                            QuizResponse.Question quiz = new QuizResponse.Question(questionText, optionsList, correctAnswer);
                            quizList.add(quiz);
                        }

                        Toast.makeText(getContext(), "Quiz loaded: " + quizList.size() + " questions", Toast.LENGTH_SHORT).show();
                        Log.d("QUIZ_LOADED", "Quiz successfully loaded with " + quizList.size() + " questions.");

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Error parsing quiz", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        );

        requestQueue.add(jsonObjectRequest);
    }
}