package com.example.personalizedlearningexperiencesapp.fragments;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.personalizedlearningexperiencesapp.MainActivity;
import com.example.personalizedlearningexperiencesapp.R;

public class Result extends Fragment {

    private int score;
    private int totalQuestions;

    public Result() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_result, container, false);

        // Get score from bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            score = bundle.getInt("score", 0);
            totalQuestions = bundle.getInt("total", 0);
        }

        TextView resultText = view.findViewById(R.id.resultText);
        Button homeButton = view.findViewById(R.id.homeButton);

        resultText.setText("Your Score: " + score + " / " + totalQuestions);

        homeButton.setOnClickListener(v -> {
            // Go back to Home screen
            ((MainActivity) getActivity()).switchFragment(new Home());
        });

        return view;
    }
}